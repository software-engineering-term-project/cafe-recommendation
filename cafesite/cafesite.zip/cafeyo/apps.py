from django.apps import AppConfig


class CafeyoConfig(AppConfig):
    name = 'cafeyo'
